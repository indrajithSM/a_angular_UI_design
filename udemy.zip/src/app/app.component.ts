import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent {
  length: number = 0;
  includesLetters = false;
  includesNumber = false;
  includesSymbols = false;
  password = '';

  inputValueChange(target: any) {
    const number = parseInt(target.value);
    if (!isNaN(number)) {
      this.length = number;
    }
  }
  letterChange() {
    this.includesLetters = !this.includesLetters;
  }
  numberChange() {
    this.includesNumber = !this.includesNumber;
  }
  symbolChange() {
    this.includesSymbols = !this.includesSymbols;
  }
  onButtonClick() {
    const number = '1234567890';
    const letters = 'abcdefghijklmnopqrstuvwxyz';
    const symbols = '!@#$%^&*()';
    let validChar = '';
    if (this.includesLetters) {
      validChar += letters;
    }
    if (this.includesNumber) {
      validChar += number;
    }
    if (this.includesSymbols) {
      validChar += symbols;
    }
    let generatePassword = '';
    for (let i = 0; i < this.length; i++) {
      const index = Math.floor(Math.random() * validChar.length);
      generatePassword += validChar[index];
    }
    this.password = generatePassword;
  }
}
